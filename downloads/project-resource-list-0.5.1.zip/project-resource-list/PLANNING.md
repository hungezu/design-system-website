# 免安装页面布局规划规则

标识：platform-layout-planning/1。状态：待接入与对照验证，不保证生成质量。本文件为唯一规则来源；MCP资料发现阶段与离线资料包携带同一版本全文，不依赖消费者安装本机Skill。仅规划，不授权改项目规则、发布或调用外部服务。

## 使用步骤

布局优先承担解释：通过信息层级、分组、对齐、间距及选中状态表达关系，避免不必要的辅助标签、重复标题、操作解释与实现说明。保留必要label和可访问名称、输入要求、错误、权限与风险反馈；不把本规则变成业务页面的说明卡片。已确认项目规范决定视觉，给定原型决定实际结构，匹配场景提供布局与交互；项目与页面可独立布局，不强制统一外壳或侧栏。

1. **锁定依据。**读取用户确认的项目MD、project/version/checksum、批准组件/API、主题、项目布局及可用页面/场景目录。区分项目业务规范与平台外壳规范。已知信息直接使用，不重复询问；只有影响选源、业务含义或权限的真实缺口才集中澄清。无法读取时列缺失，不用其他项目或当前草稿补历史版本。
2. **判断任务。**用一句话说明用户要完成的主任务，识别操作型/阅读型及其混合区域；列真实内容的最小、常见、最长范围与主次操作。按信息角色分组，不默认等大卡片，不把每个状态新建成页面。没有真实内容时明确样例/假设，不伪造业务事实。
3. **先定结构。**说明主要区域、视觉顺序、可用宽高、固定区与滚动归属；短筛选优先标签控件横排，填写优先上下排。按项目断点处理紧凑桌面，不额外套移动规则。列必要加载/空/失败/只读/未保存与恢复状态，以及键盘等价操作；模拟开关仅属明确演示层，不默认带入业务页。
4. **匹配实际资源。**同项目同版本已保存 page/binding 优先，其次匹配返回的共享 scene/layout/variant，均不匹配才用批准组件组合。只使用实际返回标识、源码闭包和依赖，不编造变体名或由截图重建已有布局。记录选用理由、继承字段、显式覆盖及宿主插槽；明确布局可用与业务接口未接的区别，不用列表参数控制所有页面。
5. **检查后交接。**核字段/动作/状态未丢失，主操作可达、无重复外壳、无相互遮挡及无意双滚动；详情返回保留筛选/页码/位置/焦点，失败保留输入。核项目主题与浮层一致，使用组件已有hover/pressed/focus/disabled配方。规划通过不代表渲染或业务通过，交付时分别记录构建、实际尺寸截图及操作验证结果。

约束：不得自主更换品牌/中性色、4.5:1规则、批准字体、分页配方或创建第二套组件库；项目特例只限明确页面/区域，不推广至其他项目。项目MD与批准组件合同冲突时列出具体冲突，按既定权威规则处理，不能静默覆盖。不要新增管理流程、模板分类或无用设置。

## 最小输出示例

以下是报告编辑任务的说明格式，不是预选所有任务的布局答案；标识须来自本次真实目录。

> 任务：边查看会话上下文边编辑报告，保存失败不丢正文。
>
> 依据：项目、版本、checksum与MD来源见本次合同；优先检索已有页面绑定。
>
> 结构：会话/输入、文档工具栏、目录、正文；按实际项目MD的宽度、断点及滚动规则处理，各滚动区域与常驻操作明确。国科信报告工作区MD §8的≤1100纵排仅适用于该项目与页面，不是平台默认。
>
> 匹配：记录实际命中的page或scene/layout/variant及源码；没有项目绑定时说明共享资源的适配理由，不虚构binding。
>
> 边界/检查：正文编辑、保存和版本由宿主提供；样例本地状态明确标记。核只读、保存失败、未保存离开、返回恢复；1440/1024实际验证完成前标未测。

## 方法来源与复用边界

本平台适配借鉴 Impeccable 的 Operate、shape、layout 方法：任务效率优先、先形成结构brief、检查分组/密度/滚动。不是原版Skill执行，不调用其启动器或下载引擎；用项目已有信息减少重复问答，并增加本平台资源发现/版本隔离约束。现有8场景实现与组件源码由平台自身提供，不来自该方法。

- [Impeccable SKILL](https://github.com/pbakaus/impeccable/blob/c1e0e5492fbb524f5df84d635ecfae7dc438ec45/.agents/skills/impeccable/SKILL.md)
- [shape](https://github.com/pbakaus/impeccable/blob/c1e0e5492fbb524f5df84d635ecfae7dc438ec45/.agents/skills/impeccable/reference/shape.md)
- [operate](https://github.com/pbakaus/impeccable/blob/c1e0e5492fbb524f5df84d635ecfae7dc438ec45/.agents/skills/impeccable/reference/operate.md)
- [layout](https://github.com/pbakaus/impeccable/blob/c1e0e5492fbb524f5df84d635ecfae7dc438ec45/.agents/skills/impeccable/reference/layout.md)
- [上游 Apache-2.0 许可证及版权声明](https://github.com/pbakaus/impeccable/blob/c1e0e5492fbb524f5df84d635ecfae7dc438ec45/LICENSE)
- [上游 NOTICE](https://github.com/pbakaus/impeccable/blob/c1e0e5492fbb524f5df84d635ecfae7dc438ec45/NOTICE.md)

上述.agents路径已在研究阶段逐项读取；此前研究读取过plugin路径，本规则统一到.agents来源，不混称完全相同字节。上游固定提交为 c1e0e5492fbb524f5df84d635ecfae7dc438ec45。开发者已通过GitHub内容API核对同一提交的SKILL、shape、operate、layout、LICENSE及NOTICE.md；来源和许可固定记录为 `artifacts/scenario-experience-20261111-r1/planning-upstream/SOURCE-LOCK.json`，各文件SHA-256与获取记录随集成包携带，不在本指南复制第二份身份。本次固定核对结论引用开发者记录，不冒称设计端独立重验文件哈希。

分发适配资料时保留本来源/适配说明；打包上游原文或衍生材料时同时附已固定的LICENSE、NOTICE及SOURCE-LOCK，标注修改，不将链接视为已附许可证全文。来源/许可已固定核对；接入后的质量效果仍未实测，不作效果保证。


适配修改声明：本平台将方法改写为以上五步，加入同项目/版本资源优先、已批准组件与宿主边界；并非上游Skill的原样执行。方法来源版权与Apache-2.0全文、适用NOTICE随本资料保留，见licenses目录。来源设计稿SHA-256：b7f24ecdffb984667f6b988eb711dd8f257861d414de7b40706b2d3771f231da。
